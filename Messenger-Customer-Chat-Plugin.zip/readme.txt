=== Messenger Customer Chat Plugin ===
Tags: messenger, customer chat, webchat, messenger wordpress plugin, livechat,
Requires at least: 3.5
Tested up to: 4.9
Stable tag: 1.6.5
License: GPLv3
Contributors: arroinua

Allows to easily add an official Messenger Customer Chat Plugin to your website.

== Description ==

This plugin allows to easily add an official Messenger Customer Chat Plugin to your website. This is not a custom live chat plugin. You will have an official Messenger Customer Chat Plugin on your website.

If you find any bugs/issues please report and I'll try to fix them asap.

**How to make this plugin work?**

* Create a Business Facebook Page or you have to be an Admin of the existed Page
* Whitelist your website's domain name in your Facebook Page settings
* Find your Page ID on www.facebook.com/your_page -> About -> Page ID at the bottom
* Setup Plugin by filling Page ID option
* The Messenger Customer Chat Plugin should appear on your webpage

**How does this plugin works?**

* This plugin adds an official Messenger Customer Chat Plugin to your website.


== Installation ==


**via Wordpress**

1. Go to the menu 'Plugins' -> 'Install' and search for 'Messenger Customer Chat Plugin'
2. Click 'install'

**Manual Installation**

1. Unzip the zip file and upload  to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu
3. Configure plugin from 'Settings > PS Menu Items'

== Changelog ==

= 1.0 (2017-12-15) =
* Initial Release

== Frequently Asked Questions ==

= How to make this plugin work? =

* Create a Business Facebook Page or you have to be an Admin of the existed Page
* Whitelist your website's domain name in your Facebook Page settings
* Find your Page ID on www.facebook.com/your_page -> About -> Page ID at the bottom
* Setup Plugin by filling Page ID option
* The Messenger Customer Chat Plugin should appear on your webpage

= How does this plugin works? =

This plugin allows to easily add an official Messenger Customer Chat Plugin to your website. This is not a custom live chat plugin. You will have an official Messenger Customer Chat Plugin on your website.
